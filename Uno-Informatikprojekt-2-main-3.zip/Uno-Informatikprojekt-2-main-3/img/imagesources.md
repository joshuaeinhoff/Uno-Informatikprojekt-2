#Image sources
Elementsymbole: https://i.pinimg.com/originals/44/02/f6/4402f634a74cbee29b2aa34297b884fc.jpg
