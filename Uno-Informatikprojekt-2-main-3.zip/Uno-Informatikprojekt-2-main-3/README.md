# Uno-Informatikprojekt-2

Informatikprojekt 2 von Sarah, Teresa und Joshua

## Idee
- Bei Uno gibt es vier verschiedene Farben die hier als Tempel mit unterschiedlichen Schwierigkeiten herhalten
    - Feuer, Wasser, Erde, Luft
- Uno-Spiel mit GegnerKI
- Spieler haben Lebensanzeige die durch Spiele reduziert wird
- Je mehr Karten der verlierende Spieler hat desto mehr schaden erleidet er
- in jedem Tempel gibt es ein kleines Rätsel und einen Tempelboss
- Jeder Boss muss im Uno-Kampf besiegt werden 
- je weiter der Spieler in der Geschichte kommt desto schwieriger werden die Rätsel und Kämpfe
- Wer den letzten Tempel (Feuertempel) bezwingt kriegt eine festgelegte Menge 5Coins als Belohnung

![Tempelelementsymbol](https://github.com/joshuaeinhoff/Uno-Informatikprojekt-2/blob/main/img/Avater%20Tempel%20Symbole.jpg)

### Schadensrechnung
- jede normale Karte macht 5 Schaden
- jede Wunschkarte macht 7 Schaden
- jede PlusVierWunschkarte macht 10 Schaden

### Story
- Kleine Story der Spielwelt
- Der Spieler bzw. die Spielerin ist die Hauptfigur eines Abenteuers, in dem er/sie Aufgaben in vier verschiedenen Tempel erledigen muss. Das ist der einzige Weg, die Welt zu retten. 


## Klassendiagramm

![Klassendiagramm](img/TempleCardsKlassendiagrammAlsSVG.svg)
