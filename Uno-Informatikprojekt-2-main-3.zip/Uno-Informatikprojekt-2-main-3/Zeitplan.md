| Datum  | Aufgabe | Verantwortliche(r) |
| ------------- | ------------- | ------------- |
| 09.11.2021 | Spielkonzept, -ablauf und Zeitplan erstellen | Alle |
| 16.11.2021 | Quizfragen und Fragenpool fertigstellen | Sarah, Teresa |
|  | Klassendiagramm aktualisieren | Teresa |
|  | Spiellogik, KI und Spielfeld erweitern | Joshua |
|  | Mit der Dokumentation anfangen | Sarah |
| 23.11.2021 | Uno Spiel sollte möglichst funktionieren  |
| 30.11.2021 | Visuelle darstellung  |
| 07.12.2021 | Das Spiel sollte fertig sein  |
| 14.12.2021 | Anfang vom Tutorial  |
| 21.12.2021 | ...  |
| 04.01.2022 | ...  |
| 11.01.2022 | ...  |
| 18.01.2022 | ...  |
