# Fragen

# Anmerkungen

- Auswählen ob Spieler OOP1 oder OOP2 ist
- mind. 5 Fragen pro OOP1/2 und pro Temple -> 40 Fragen
- Quizfragenpool als eigene Klasse

## Story
- Schatzsuche
- Reihenfolge der Tempel: Wasser, Luft, Erde, Feuer

## Umsetzung
- Klasse Spieler: 2 (random und mit Strategie)