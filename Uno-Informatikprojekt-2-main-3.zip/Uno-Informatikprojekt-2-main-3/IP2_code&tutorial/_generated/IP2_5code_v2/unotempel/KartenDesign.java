package unotempel;

/**<br>
 * <br>
 <br>*/
public class KartenDesign {

	public final static String gruen = "#465726";
    public final static String rot = "#F57461";
    public final static String blau = "#64A5BB";
    public final static String schwarz = "#232B2B";
    public final static String gelb = "#FDD782";
    public final static String weiss = "#F7F9EF";
    public final static String grau = "#3B444B";
    
    

}