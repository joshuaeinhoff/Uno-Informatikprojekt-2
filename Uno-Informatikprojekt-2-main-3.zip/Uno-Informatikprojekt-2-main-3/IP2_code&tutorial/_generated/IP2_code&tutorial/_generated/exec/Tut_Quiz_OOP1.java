class Tut_Quiz_OOP1
{
public static void main(String[] args)
{ System.setOut(new FiveCodePrintStream(System.out));

/** 4.3.1 Quizfragen auslesen <br>
* Private Funktion liest, speichert und gibt Datens&auml;tze aus einer bestimmten Datei als String-Array zur&uuml;ck<br>
* @param tempelFarbe - String mit der Farbe des Tempels<br>
* @return Array von String<br>
<br>*/
private String[] quizfragenAuslesen(String tempelFarbe) {
  // Variablen zum Speichern der aus einer Datei gelesenen Datensätze
  String datensatz; // Zum Speichern eines Datensatzes
  String[] datensaetze = new String[50]; // d.h. Speicherplatz für max. 10 Quizfragen
  int anzahlDatensaetze = 0; // Anzahl von Datensätzen speichern und mitzählen

  // try-Block - Es wird versucht, aus einer Datei mithilfe eines FileReaders Datensätze zu lesen
  try {
    // Variable zum Speichern des Dateinamens
    String dateiName = "";
    // Je nach Farbe und Quizniveau des Tempels wird ein bestimmter Dateipfad gespeichert
    switch(tempelFarbe) {
      case "blau": // Wasser-Tempel
        if(niveau == 1)
          dateiName = "../../quizfragen/fragen_t1_oop1.txt";
                else if(niveau == 2)
                    dateiName = "../../quizfragen/fragen_t1_oop2.txt";
                break;
      case "gelb": // Luft-Tempel
        if(niveau == 1)
          dateiName = "../../quizfragen/fragen_t2_oop1.txt";
        else if(niveau == 2)
          dateiName = "../../quizfragen/fragen_t2_oop2.txt";
        break;
      case "gruen": // Erde-Tempel
                if(niveau == 1)
          dateiName = "../../quizfragen/fragen_t3_oop1.txt";
        else if(niveau == 2)
          dateiName = "../../quizfragen/fragen_t3_oop2.txt";
        break;
      case "rot": // Feuer-Tempel
        if(niveau == 1)
          dateiName = "../../quizfragen/fragen_t4_oop1.txt";
        else if(niveau == 2)
          dateiName = "../../quizfragen/fragen_t4_oop2.txt";
        break;
    }

    // Kanonische Erzeugung eines FilterReaders zum Lesen aus einer Datei
    FilterReader fr = new FilterReaderDatensatz(
                          new FilterReaderZeichen(
                          new BufferedReader(
                          new FileReader(dateiName))));

    // Variablen zum Lesen aus einer Datei
    int off = 0; // Anfang-Index für einen Array
    int len = 300; // Max. Länge von Zeichen
    int num = 0; // Anzahl von gelesenen Zeichen

    // Buffer zum Lesen und Daten aus der Datei zwischenzuspeichern
    char[] buf = new char[len + off];
    // Solange Ende des Streams nicht erreicht wird
    while (num != -1) {
      // Zeichen lesen
      num = fr.read(buf, off, len);
      // Wenn nicht Ende des Streams
      if (num != -1) {
        // String aus dem Buffer erzeugen
                datensatz = new String(buf, off, num);
                // Datensatz in den String-Array speichern und Anzahl von Datensätzen inkrementieren
                datensaetze[anzahlDatensaetze++] = datensatz;
            }
        }

  // catch-Exception - Fall IOException abgefangen wird, wird eine Meldung auf der Konsole ausgegeben
  } catch(IOException ioe) {
    ioe.getMessage();
  }
  // String-Array von Datensätzen zurückgeben
    return datensaetze;
}

}


Tut_Quiz_OOP1() {
}
}